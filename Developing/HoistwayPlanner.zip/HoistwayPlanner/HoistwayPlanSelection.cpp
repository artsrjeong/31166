// HoistwayPlanSelection.cpp
//	Module for selecting best hoistway plan from the candidates
#include "stdafx.h"
#include <math.h>
#include <crtdbg.h>
#include "HoistwayPlanSelection.h"
#define	EXTERN
#include "HoistwaySchedule.h"
#undef	EXTERN
#define	EXTERN	extern
#include "HoistwayPlanner.h"
#undef	EXTERN
#include "..\COGS\2DSIM_DEFS.H"
#include "..\COGS\2dinterfacefunctiontype.h"

extern GetCarState_T	GetCarState;


#ifdef	WITH_DEBUG
extern int virtualAssign;
#endif
// door dwell time for normal demand stop
// currently not consider type
//	mimic of DwellTimeCurrent , CAGS dwell time based
// argument car is upper=1, lower=0
float	HoistwaySchedule::DoorDwellTime(int car,int floor,int board,int deboard,int type)
{
	int total;
	float min_dwell, dwell, lobbyDwell, stopDwell;
	float NorioriTime;
	// shs consider type
	/*
	if (type==HANDICAPPED_STOP)
		return 0;
	*/
	if(board > capacity[car])
		board = capacity[car];

	total = board + deboard;


	if (USERFLOOR(floor) == lobby1Floor || USERFLOOR(floor) == lobby2Floor)
	{
		if((board != 0) && (deboard != 0))
			lobbyDwell = t_hall_max_dwell;
		else
			lobbyDwell = t_lobby_dwell;
	}
	else
		lobbyDwell = 0.0;

	if (board == 0)
		stopDwell = t_car_min_dwell;
	else if (deboard == 0)
		stopDwell = t_hall_min_dwell;
	else
		stopDwell = t_hall_max_dwell;
	
	//min_dwell = max(lobbyDwell, stopDwell);
	if (lobbyDwell>stopDwell)
	{
		min_dwell=lobbyDwell;
	}
	else
	{
		min_dwell=stopDwell;
	}

	
	NorioriTime = 1.0;
	dwell = 2.1F + total*NorioriTime/2.0F; //Later, decide first parameter whether it is 2.1 or 2.0.
	if(dwell > 9.2)
		dwell -= 0.1F;
	
	if (dwell < min_dwell)
		return min_dwell;
	else
		return dwell;
}

float  HoistwaySchedule::DecelTime(int car,int origin,int dest)
{
	float dist;
	float acc,vel,jerk;
	float decelTime;

	dist = (float)fabs(FloorHeightTable[origin]-FloorHeightTable[dest]);

	acc=ACC[car];vel=VEL[car];jerk=JERK[car];
	if (dist<=0.001)  // dist is few return 0
		return 0;
	if (dist>=fullSpeedThres[car])
	{
		decelTime=dist/vel;
	}
	else if (dist>=fullAccThres[car])
	{
		decelTime=-acc/(2*jerk)+(float)(sqrt(acc*acc*acc+4*dist*jerk*jerk)/(2*jerk*sqrt(acc)));
	}
	else
	{
		decelTime=(float)pow(dist/(2*jerk),1/3);
	}
	decelTime+=MAKE_FLOAT_TIME(carInfo[car].tStartDelay);
	return decelTime;
}

float HoistwaySchedule::RunTime(int car,int origin,int dest)
{
	float dist;
	float runTime;
	float acc,vel,jerk;

	dist=(float)fabs(FloorHeightTable[origin]-FloorHeightTable[dest]);
	acc=ACC[car];vel=VEL[car];jerk=JERK[car];
	if (dist<=0.001)
	{
		runTime=0;
	}
	else if (dist>=fullSpeedThres[car])
	{
		runTime=dist/vel+acc/jerk+vel/acc;
	}
	else if (dist>=fullAccThres[car])
	{
		runTime=acc/jerk+(float)(sqrt(acc*acc*acc+4*dist*jerk*jerk)/(jerk*sqrt(acc)));
	}
	else
	{
		runTime=(float)pow(32*dist/jerk,1/3);
	}
	if (runTime>0)
		runTime+=MAKE_FLOAT_TIME((carInfo[car].tStartDelay+carInfo[car].tStopDelay));
	return runTime;
}

// Compensate the static infomation to float value
void HoistwaySchedule::Initialize(int upperCarID,int lowerCarID)
{
	int car;
	float jerk,acc,vel;
	int car_id;

	carID[LOWER_CAR]=lowerCarID; // shs050810 For 1-D check
	carID[UPPER_CAR]=upperCarID; // shs050810 For 1-D check
	//plan=(HoistwayPlan)NULL;

//	DoorOpeningTime=1.5; // second
//	DoorClosingTime=2.5; // second
	f_offset=bdInfo.f_offset;

	for (car=0;car<MAX_CARS_IN_HOISTWAY;car++)
	{
		car_id=carID[car];
		capacity[car]=carInfo[car_id].capacity;

		doorOpeningTime[car]=MAKE_FLOAT_TIME(carInfo[car_id].tDoorOpening);
		doorClosingTime[car]=MAKE_FLOAT_TIME(carInfo[car_id].tDoorClosing);

		jerk=JERK[car]=MAKE_FLOAT_SPEED(carInfo[car_id].maxJerk);
		acc=ACC[car]=MAKE_FLOAT_SPEED(carInfo[car_id].maxAcceleration);
		vel=VEL[car]=MAKE_FLOAT_SPEED(carInfo[car_id].maxVelocity);
//		SAFETY_DECEL[car]=3;//

		fullSpeedThres[car]=(acc*acc*vel+vel*vel*jerk)/(jerk*acc);
		fullAccThres[car]=(2*acc*acc*acc)/(jerk*jerk);
		doorOperatingTime[car]=doorOpeningTime[car]+doorClosingTime[car];
		startDelay[car]=MAKE_FLOAT_TIME(carInfo[car_id].tStartDelay);
		stopDelay[car]=MAKE_FLOAT_TIME(carInfo[car_id].tStopDelay);
		
	}
	lobby1Floor=bdInfo.lobby1Floor;
	lobby2Floor=bdInfo.lobby2Floor;
	lobby3Floor=bdInfo.lobby3Floor;

	t_car_min_dwell=MAKE_FLOAT_TIME(param.tCarMinDwell);
	t_hall_min_dwell=MAKE_FLOAT_TIME(param.tHallMinDwell);
	t_hall_max_dwell=MAKE_FLOAT_TIME(param.tHallMaxDwell);
	t_lobby_dwell=MAKE_FLOAT_TIME(param.tLobbyDwell);
	BoardK[0]=MAKE_FLOAT_TIME(param.V);//waiting
	BoardK[1]=MAKE_FLOAT_TIME(param.W); // boarding
	WaitTimeK[0]=MAKE_FLOAT_TIME(param.A1W);	// A1W
	WaitTimeK[1]=MAKE_FLOAT_TIME(param.A2W);	// A2W
	ServiceTimeK[0]=MAKE_FLOAT_TIME(param.A1S); // A1S
	ServiceTimeK[1]=MAKE_FLOAT_TIME(param.A2S); // A2S

	for (int i=0;i<MAX_FLOOR;i++)
		FloorHeightTable[i]=MAKE_FLOAT_SPEED(bdInfo.landingPosition[i]);

	previousStopFloor[UPPER_CAR]=::previousStopFloor[upperCarID];
	previousStartTime[UPPER_CAR]=::previousStartTime[upperCarID];
	previousStopFloor[LOWER_CAR]=::previousStopFloor[lowerCarID];
	previousStartTime[LOWER_CAR]=::previousStartTime[lowerCarID];
	
}

void HoistwaySchedule::SetPlan(HoistwayPlan &planCandidate)
{
	plan=planCandidate;
	int car,stopLink;
	int stopNo;
	for (car=0;car<MAX_CARS_IN_HOISTWAY;car++) // for each car in a hoistway
	{
		if (carID[car]<0) 
			continue; // shs050810 For 1-D check 

		stopLink=plan.sequences[car].sequence_start;
		stopNo=0;
		while (stopLink!=-1)
		{
			timing[car][stopNo].sLink=stopLink; // sequence link not index
			timing[car][stopNo].stopType=plan.sequences[car].sequence[stopLink].type;
			stopLink=plan.sequences[car].sequence[stopLink].next;
			stopNo++;
		}
		nStop[car]=stopNo;	// number of stops
		// shs delete
//		previousStopFloor[car]=0;
//		previousStartTime[car]=0;
	}
}

// after SetPlan nominal timing can be calculated
void HoistwaySchedule::NominalTiming(void)
{
	int car,stopLink;
	int prevFloor,currentFloor;
	int stopNo;
	int boarding,deboarding;
	int type;
	//int oper;
	float eventTime;
	float prevTime;

	int carid;
	for (car=0;car<MAX_CARS_IN_HOISTWAY;car++) // for each car in a hoistway
	{
		carid=carID[car];
		if (carid<0) continue; // shs050810 for 1-D consideration	
//		GetCarState(carid,&carState[car]); // shs050810
		
		eventTime=MAKE_FLOAT_TIME(carState[car].tStartOper);

		if (carState[car].motionState==MOVING)
		{	
			prevTime=eventTime;
			prevFloor=carState[car].origin;
			stopNo=0;
		}
		else
		{	// STOP
			stopLink=timing[car][0].sLink;
			currentFloor=plan.sequences[car].sequence[stopLink].floor;
			type=plan.sequences[car].sequence[stopLink].type;
			// assume when stop, UpdateState in exec didn't update board,deboard
			boarding=carState[car].nBoard;
			deboarding=carState[car].nDeboard;
			prevFloor=currentFloor;
			switch (carState[car].frontDoorState)
			{	
				case DOORS_CLOSING:
					if (type==STOP_TYPE_DEMAND && currentFloor==prevFloor) 
					{	// reopen case
						eventTime=MAKE_FLOAT_TIME(carState[car].ctCurrent); // closed and reopen start time
						prevTime=eventTime+doorOpeningTime[car]
							+doorClosingTime[car]+
							DoorDwellTime(car,prevFloor,plan.sequences[car].sequence[stopLink].boarding,
							0,STOP_TYPE_DEMAND);
					}
					else
					{	// closed time
						prevTime=eventTime+doorClosingTime[car];
						eventTime=prevTime;
					}
					break;
				case DOORS_OPENED:
					prevTime=eventTime+doorClosingTime[car]
						+DoorDwellTime(car,prevFloor,boarding+plan.sequences[car].sequence[stopLink].boarding,
							deboarding,STOP_TYPE_DEMAND);// at opened deboard is updated
					eventTime-=doorOpeningTime[car]; // compensation for opening time

					break;
				case DOORS_OPENING:
					prevTime=eventTime+doorClosingTime[car]
						+doorOpeningTime[car]
						// COGS update board at door opening end,deboard at door dwell end, so it is needed to update by only plan
						// boarding and deboarding is not yet updated
						+DoorDwellTime(car,prevFloor,plan.sequences[car].sequence[stopLink].boarding,
							plan.sequences[car].sequence[stopLink].deboarding,STOP_TYPE_DEMAND); // Door time synchro
					break;
				default: // DOORS_CLOSED
					prevTime=MAKE_FLOAT_TIME(carState[car].ctCurrent); // current time
					if (carState[car].origin!=currentFloor)  // just arrived
					{	
						eventTime=prevTime;
					}
					if (plan.sequences[car].sequence[stopLink].type==STOP_TYPE_DEMAND)
					{   // Adding open,close,dwell time
						// boarding debaording 
						prevTime+=DoorTime(car,prevFloor,/*boarding+*/plan.sequences[car].sequence[stopLink].boarding,
							plan.sequences[car].sequence[stopLink].deboarding/*deboarding*/,STOP_TYPE_DEMAND);
					}
					break;
			}
			timing[car][0].arrivalTime=eventTime;
			timing[car][0].departureTime=prevTime;
			timing[car][0].nominalStopDuration=prevTime-eventTime;
			timing[car][0].extendedStopDuration=0;
			stopNo=1;
		}

//		prevFloor=previousStopFloor[car];
//		prevTime=previousStartTime[car];
		for (;stopNo<nStop[car];stopNo++)
		{
			stopLink=timing[car][stopNo].sLink;
			currentFloor=plan.sequences[car].sequence[stopLink].floor;
			type=plan.sequences[car].sequence[stopLink].type;
			
			if (type==STOP_TYPE_CONDITIONAL || type == STOP_TYPE_PIVOT || type==STOP_TYPE_PARKING || type == STOP_TYPE_YIELD)
			{
				timing[car][stopNo].decelTime=prevTime+DecelTime(car,prevFloor,currentFloor);
				// redundant shs
				timing[car][stopNo].arrivalTime=prevTime+RunTime(car,prevFloor,currentFloor);
				timing[car][stopNo].nominalStopDuration=0;
				timing[car][stopNo].extendedStopDuration=0;
				timing[car][stopNo].departureTime=timing[car][stopNo].arrivalTime;
				//timing[car][stopNo].sLink=stopLink;
				//timing[car][stopNo].stopType=STOP_TYPE_CONDITIONAL;
			}
			else // demand stop or stoptype-served
			{
				timing[car][stopNo].decelTime=prevTime+DecelTime(car,prevFloor,currentFloor);
				timing[car][stopNo].arrivalTime=prevTime+RunTime(car,prevFloor,currentFloor);
				boarding=plan.sequences[car].sequence[stopLink].boarding;
				deboarding=plan.sequences[car].sequence[stopLink].deboarding;
				
				timing[car][stopNo].nominalStopDuration=DoorTime(car,currentFloor,boarding,deboarding,type);
				timing[car][stopNo].extendedStopDuration=0;
				timing[car][stopNo].departureTime=timing[car][stopNo].arrivalTime
					+timing[car][stopNo].nominalStopDuration;

				//timing[car][stopNo].sLink=stopLink;
				//timing[car][stopNo].stopType=type;				

				prevTime=timing[car][stopNo].departureTime;
				prevFloor=currentFloor;
			}
		}
	}
}


void HoistwaySchedule::FollowPlanTiming(void)
{
	int currentRelation[MAX_CARS_IN_HOISTWAY];
	int currentPointer[MAX_CARS_IN_HOISTWAY];
	CoordinationDirector direct;
// tbd
	int flag;
	flag=0;
	int car;
	
	for (car=0;car<MAX_CARS_IN_HOISTWAY;car++)
	{
		if (carID[car]<0) return;  // shs050810 for 1-D consideration
		currentRelation[car]=0;
		currentPointer[car]=0;
	}
	while(flag<MAX_CARS_IN_HOISTWAY)	// till search completed
	{
		direct=FindFirstRelation(currentPointer,currentRelation);
		
		if (direct.car==-1) // search completed Nothing to do
		{
			break;
		}
		else
		{
			FollowOneCoordination(direct); //timing adjustment for coordination
			UpdateCurrentPointer(currentPointer,currentRelation,direct); // one step further to pointer
			//	check complete of sequence
			flag=0;
			for (int i=0;i<MAX_CARS_IN_HOISTWAY;i++)
			{
				if (currentPointer[i]>=nStop[i])
					flag+=1;
			}
		}
	}
}

T_HPSCORE HoistwaySchedule::Scoring(void)
{
	T_HPSCORE score;

	score=getTimingScore();
	// scoring for timing - wait,
	return score;
}

void	HoistwaySchedule::SetCarStates(CarState *uCarState,CarState *lCarState)
{
	memcpy(&carState[0],lCarState,sizeof(CarState));
	memcpy(&carState[1],uCarState,sizeof(CarState));
}

T_HPSCORE HoistwaySchedule::TimingAndScoring(int upperCar,int lowerCar,HoistwayPlan &candidate)
{
	T_HPSCORE score;
	Initialize(upperCar,lowerCar);
	SetPlan(candidate);
	//T_ResetDETimes(); //temporary shs
	NominalTiming();
	FollowPlanTiming();
	score=Scoring();
	return score;
}
/*
 * Calculate timing and scoring given a hoistway plan
 * The car Id is for the class to retrieve related hoistway info
 * Debug info will be dumped to a file. 
 */
T_HPSCORE HoistwaySchedule::TimingAndScoring(int upperCar,int lowerCar,HoistwayPlan &candidate, short planIndex, FILE *fp)
{
	T_HPSCORE score;
	Initialize(upperCar,lowerCar);
	SetPlan(candidate);

#ifdef	WITH_DEBUG
	fprintf(fp,"Candidate %d\n",planIndex);
	plan.print(fp);
#endif
	// T_ResetDETimes(); //temporary shs
	NominalTiming();

#ifdef	WITH_DEBUG 
	fprintf(fp,"Nominal Timing\n");
	timingPrint(fp);
#endif
	FollowPlanTiming();
#ifdef	WITH_DEBUG		
	fprintf(fp,"Planned Timing\n");
	timingPrint(fp);
#endif
	score=Scoring();
#ifdef	WITH_DEBUG			// CSW072505: print for debug only
	fprintf(fp,"Score=%f\n\n",score);
	
#endif

	return score;
}

HPSCORE_T	HoistwayPlanSelection(int upperCarID,int lowerCarID,
			 int candidateSize,
			HoistwayPlan *candidatePlan,HoistwayPlan *bestPlan)
{
	int iPlan;
	T_HPSCORE bestScore,currentScore;
	int bestPlanIndex=-1;
	HoistwaySchedule Hs;
	//HoistwayPlan best;
	bestScore=(T_HPSCORE)T_HPSCORE_MAX;
	char FileName[100];
	sprintf(FileName,"HSchedule-%d-%d",lowerCarID,upperCarID);
#ifdef	WITH_DEBUG
	if (virtualAssign>=0)
	{
		sprintf(FileName,"%sV%d",FileName,virtualAssign);
	}

	strcat(FileName,".txt");

	FILE *fp;
	fp=fopen(FileName,"w");  // clear older contents
	fclose(fp);
#endif
	Hs.Initialize(upperCarID,lowerCarID);
	for (iPlan=0;iPlan<candidateSize;iPlan++)
	{
		Hs.SetPlan(candidatePlan[iPlan]);
#ifdef	WITH_DEBUG
		fp=fopen(FileName,"a");				// CSW072505: only print for debug
		fprintf(fp,"Candidate %d\n",iPlan);
		Hs.plan.print(fp);
		fclose(fp);
#endif

		// temporary
//		Hs.T_ResetDETimes();

		Hs.NominalTiming();


#ifdef	WITH_DEBUG // CSW072505: only print for debug
		fp=fopen(FileName,"a");
		fprintf(fp,"Nominal Timing\n");
		Hs.timingPrint(fp);
		fclose(fp);
#endif

		Hs.FollowPlanTiming();

#ifdef	WITH_DEBUG		// CSW072505: print for debug only
		fp=fopen(FileName,"a");
		fprintf(fp,"Planned Timing\n");
		Hs.timingPrint(fp);
		fclose(fp);
#endif

		currentScore=Hs.Scoring();

#ifdef	WITH_DEBUG			// CSW072505: print for debug only
		fp=fopen(FileName,"a");
		fprintf(fp,"Score=%f\n\n",currentScore);
		fclose(fp);
#endif

		if (iPlan==0)
		{
			bestScore=currentScore;
			bestPlanIndex=iPlan;
		}
		if (bestScore>currentScore)
		{
			bestScore=currentScore;
			bestPlanIndex=iPlan;
		}
	}

	
	if (bestPlanIndex>=0)
	{
		*bestPlan=candidatePlan[bestPlanIndex];
#ifdef	WITH_DEBUG			//	CSW072505: print for debug only
		fp=fopen(FileName,"a");
		fprintf(fp,"* Best Plan : %d candidate *\n",bestPlanIndex);
		candidatePlan[bestPlanIndex].print(fp);
		Hs.SetPlan(*bestPlan);
		Hs.NominalTiming();
		Hs.FollowPlanTiming();
		Hs.timingPrint(fp);
		fprintf(fp,"Score : %f\n",bestScore);
		fclose(fp);
#endif

		return (HPSCORE_T) bestScore;
	}
	else
	{
		//bestPlan=NULL;
		bestPlan->sequences[UPPER_CAR].sequence_start=-1;
		bestPlan->sequences[LOWER_CAR].sequence_start=-1;
#ifdef	WITH_DEBUG
		fp=fopen("HScheduleDebug.txt","a");
		if (virtualAssign<0)
			_RPT2(_CRT_WARN,"NO BEST PLAN for upper=%d,lower=%d\n",upperCarID,lowerCarID);
		else
			_RPT1(_CRT_WARN,"No Best Plan for virtual assign %d\n",virtualAssign);

		fprintf(fp,"No Best Plan found\n");
		fclose(fp);
#endif
		return 0;
	}
	
}

#define	MAX_RELATION	2		// ARRIVAL and DEPARTURE PRECEDESSOR
// find first relationship and return that information
CoordinationDirector	HoistwaySchedule::FindFirstRelation(int currentPointer[]
		,int currentRelation[])
{
	int car,othercar;
//	int point[MAX_CARS_IN_HOISTWAY],relation[MAX_CARS_IN_HOISTWAY];
	CoordinationDirector direct[MAX_CARS_IN_HOISTWAY];
	CoordinationDirector codi;
	int link,foundFlag;
	int tpoint,relationId,tpred;
	int currentLowerIndex,currentUpperIndex;
	int lowerPredecessorIndex,upperPredecessorIndex;

	for (car=0;car<MAX_CARS_IN_HOISTWAY;car++)
	{
		foundFlag=0; direct[car].car=-1; // not found
		tpoint=currentPointer[car];
		relationId=currentRelation[car];
		othercar=(car+1)%MAX_CARS_IN_HOISTWAY;
		while(tpoint<nStop[car])
		{
			link=timing[car][tpoint].sLink;
			for (;relationId<MAX_RELATION && foundFlag==0;relationId++)
			{
				switch (relationId)
				{
				case 0: 
					if (plan.sequences[car].sequence[link].arrival_predecessor!=-1)
					{
						direct[car].car=car;
						direct[car].current=tpoint;
						tpred=plan.sequences[car].sequence[link].arrival_predecessor;
						direct[car].predecessor=tpred;
						//direct[car].predecessor=plan.sequences[othercar].sequence[tpred].index;
#ifdef	WITH_DEBUG
						_ASSERT(plan.sequences[othercar].sequence[tpred].index>=0);

						if(timing[othercar][plan.sequences[othercar].sequence[tpred].index].sLink!=tpred)
						{
							_RPT0(_CRT_WARN,"link mismatch\n");
						}
#endif
						direct[car].relation=STOP_PREDECESSOR_ARRIVAL;

						foundFlag=1;
					}
					break;
				case 1:
					if (plan.sequences[car].sequence[link].departure_predecessor!=-1)
					{
						direct[car].car=car;
						direct[car].current=tpoint;
						tpred=plan.sequences[car].sequence[link].departure_predecessor;
						direct[car].predecessor=tpred;
						//direct[car].predecessor=plan.sequences[othercar].sequence[tpred].index;
#ifdef	WITH_DEBUG
						_ASSERT(plan.sequences[othercar].sequence[tpred].index>=0);
						if(timing[othercar][plan.sequences[othercar].sequence[tpred].index].sLink!=tpred)
						{
							_RPT0(_CRT_WARN,"link mismatch\n");
						}
#endif
						direct[car].relation=STOP_PREDECESSOR_DEPARTURE;

						foundFlag=1;
					}
					break;
				}
			}
			if (foundFlag)
			{	//	update current pointer for later use (not to search searched area)
				currentPointer[car]=tpoint;
				currentRelation[car]=direct[car].relation;
				break;
			}
			relationId=0;
			tpoint++;
		}
	}
	// Compare direct to find which is better and error check
	if (MAX_CARS_IN_HOISTWAY==2)
	{
		if (direct[LOWER_CAR].car==-1)
		{
			if (direct[UPPER_CAR].car==-1)
			{
				codi.car=-1;
			}
			else
			{
				codi=direct[UPPER_CAR];
			}
		}
		else if (direct[UPPER_CAR].car==-1)
		{
			codi=direct[LOWER_CAR];
		}
		else
		{
			_ASSERT(direct[LOWER_CAR].current>=0 && direct[UPPER_CAR].current>=0);
			link=timing[LOWER_CAR][direct[LOWER_CAR].current].sLink;
			currentLowerIndex=plan.sequences[LOWER_CAR].sequence[link].index;
			lowerPredecessorIndex=plan.sequences[UPPER_CAR].sequence[direct[LOWER_CAR].predecessor].index;

			link=timing[UPPER_CAR][direct[UPPER_CAR].current].sLink;
			currentUpperIndex=plan.sequences[UPPER_CAR].sequence[link].index;
			upperPredecessorIndex=plan.sequences[LOWER_CAR].sequence[direct[UPPER_CAR].predecessor].index;

			if (lowerPredecessorIndex<currentUpperIndex)
			{	// Lower car's coordination director is earlier
				if (upperPredecessorIndex<currentLowerIndex)
				{ // check
	#ifdef	WITH_DEBUG
					_RPT0(_CRT_WARN,"HM Link Error-Crossed 1\n");
	#endif
					codi.car=-1;
				}
				else
				{
					codi=direct[LOWER_CAR];
				}
			}
			else if (lowerPredecessorIndex>currentUpperIndex)
			{
				if (upperPredecessorIndex>currentLowerIndex)
				{ // check
	#ifdef	WITH_DEBUG
					_RPT0(_CRT_WARN,"HM Link Error-Crossed 2\n");
	#endif
					codi.car=-1;
				}
				codi=direct[UPPER_CAR];
			}
			else
			{	// lowerPredecessor==currentUpperIndex
				if (upperPredecessorIndex<currentLowerIndex)
				{ // Lower car passed upper car predecessor already, arrange upper car
					codi=direct[UPPER_CAR];
				}
				else if (upperPredecessorIndex>currentLowerIndex)
				{
					codi=direct[LOWER_CAR];
				}
				else
				{	// arrival and departure prededence is same node for upper car and lower car
					if (direct[LOWER_CAR].relation<direct[UPPER_CAR].relation)
					{
						codi=direct[LOWER_CAR];
					}
					else if (direct[LOWER_CAR].relation>direct[UPPER_CAR].relation)
					{
						codi=direct[UPPER_CAR];
					}
					else
					{
		#ifdef	WITH_DEBUG
						_RPT0(_CRT_WARN,"Error of linking\n");
		#endif
						codi.car=-1;
					}
				}
			}
		}
	}
	else	// not applicable
	{	// 1-D
	}
	return codi;
}

#define	DOOR_EXTENSION	0

// Only assume two cars in a hoistway
// use found relationship and coordinate timing according to that
void HoistwaySchedule::FollowOneCoordination(CoordinationDirector direct)
{
	int car,othercar;
	int tpredIndex;
	float extendTime;
	car=direct.car;
	othercar=(car+1)%MAX_CARS_IN_HOISTWAY; //two cars in a hoistway
	tpredIndex=plan.sequences[othercar].sequence[direct.predecessor].index;

	if (plan.sequences[car].sequence[timing[car][direct.current].sLink].type==STOP_TYPE_CONDITIONAL)
	{	// current conditional stop
		if (plan.sequences[othercar].sequence[direct.predecessor].type==STOP_TYPE_CONDITIONAL)
		{	// predecessor conditional stop
			if (direct.relation==STOP_PREDECESSOR_ARRIVAL)
			{
				if (timing[car][direct.current].decelTime<timing[othercar][tpredIndex].decelTime)
				{
					extendTime=timing[othercar][tpredIndex].decelTime-timing[car][direct.current].decelTime;
					propagateDelay(car,extendTime,direct.current-1); 
				}
			}
			else if (direct.relation==STOP_PREDECESSOR_DEPARTURE)
			{
				if (timing[car][direct.current].decelTime<timing[othercar][tpredIndex].departureTime)
				{
					extendTime=timing[othercar][tpredIndex].decelTime-timing[car][direct.current].decelTime;
					propagateDelay(car,extendTime,direct.current); 
				}			
			}
		}
		else
		{
			if (direct.relation==STOP_PREDECESSOR_ARRIVAL)
			{
				if (timing[car][direct.current].decelTime<timing[othercar][tpredIndex].arrivalTime)
				{
					extendTime=timing[othercar][tpredIndex].arrivalTime-timing[car][direct.current].decelTime;
					propagateDelay(car,extendTime,direct.current-1); 
				}
			}
			else if (direct.relation==STOP_PREDECESSOR_DEPARTURE)
			{
				if (timing[car][direct.current].decelTime<timing[othercar][tpredIndex].departureTime)
				{
					extendTime=timing[othercar][tpredIndex].departureTime-timing[car][direct.current].decelTime;
					propagateDelay(car,extendTime,direct.current); 
				}			
			}	
		}
	}	// end current conditional stop processing
	else
	{	// shs need check predecessor is conditional stop
		if (plan.sequences[othercar].sequence[direct.predecessor].type==STOP_TYPE_CONDITIONAL)
		{
			if (direct.relation==STOP_PREDECESSOR_ARRIVAL)
			{
				if (timing[car][direct.current].arrivalTime<timing[othercar][tpredIndex].decelTime)
				{
					extendTime=timing[othercar][tpredIndex].decelTime-timing[car][direct.current].arrivalTime;
					propagateDelay(car,extendTime,direct.current-1); 
				}
			}
			else if (direct.relation==STOP_PREDECESSOR_DEPARTURE)
			{
				if (timing[car][direct.current].decelTime<timing[othercar][tpredIndex].departureTime)
				{
					extendTime=timing[othercar][tpredIndex].decelTime-timing[car][direct.current].departureTime;
					propagateDelay(car,extendTime,direct.current); 
				}			
			}
		}
		else
		{
			if (direct.relation==STOP_PREDECESSOR_ARRIVAL)
			{	// timing from previous stop's departure time adjustment is needed
				if (timing[othercar][tpredIndex].arrivalTime>
					timing[car][direct.current].arrivalTime)
				{ // adjust departure timing of stop [direct.current-1] and afterwards
					// propagate delay 'extendTime' of car from seqNo, fromOperation
					extendTime=timing[othercar][tpredIndex].arrivalTime-timing[car][direct.current].arrivalTime;
					propagateDelay(car,extendTime,direct.current-1); 
				}
			}
			else if (direct.relation==STOP_PREDECESSOR_DEPARTURE)
			{	// timing from current stop door dwell time adjustment is needed
				if (timing[othercar][tpredIndex].departureTime>
					timing[car][direct.current].departureTime)
				{ // adjust departure timing of stop [direct.current-1] and afterwards
					extendTime=timing[othercar][tpredIndex].departureTime-timing[car][direct.current].departureTime;
					// propagate delay 'extendTime' of car from seqNo (currently door extension)
					propagateDelay(car,extendTime,direct.current); 
				}
			}
		}
	}	// end not current conditional stop
}

void HoistwaySchedule::UpdateCurrentPointer(int currentPointer[]
		,int currentRelation[],CoordinationDirector direct) // update current pointer for next usage after current found relationship
{
	if (direct.car<0 || direct.car>MAX_CARS_IN_HOISTWAY)
		return;
	currentPointer[direct.car]=direct.current;
	if (direct.relation==STOP_PREDECESSOR_ARRIVAL)
	{
		currentRelation[direct.car]=STOP_PREDECESSOR_DEPARTURE;
	}
	else if (direct.relation==STOP_PREDECESSOR_DEPARTURE)
	{
		currentRelation[direct.car]=STOP_PREDECESSOR_ARRIVAL;
		currentPointer[direct.car]+=1;
	}
	else
	{
	}
}

//
int	HoistwaySchedule::propagateDelay(int car,float extendTime,int propagateStartseq)
{
	int seq;
	int ret=FALSE; // FALSE: cannot correct timing, TRUE: correct timing

	seq=propagateStartseq;
	// changing the door dwell of conditional stop have no effect on the following timing
	while (seq>=0 && timing[car][seq].stopType==STOP_TYPE_CONDITIONAL)
		seq--;
	if (seq<0)
	{
		ret=FALSE;
		seq=0;
	}
	else
		ret=TRUE;

	if (seq<nStop[car])  // change timing (door dwell)
	{
		timing[car][seq].extendedStopDuration+=extendTime;
		timing[car][seq].departureTime+=extendTime;
	}
	seq++;
	// by extension of previous timing, that timing propagate till the end
	for (;seq<nStop[car];seq++)
	{	 
		timing[car][seq].decelTime+=extendTime;
		timing[car][seq].arrivalTime+=extendTime;
		timing[car][seq].departureTime+=extendTime;
	}
	return ret;
}

// need more consideration : shs
float HoistwaySchedule::getTimingScore(void)
{
	int stop,originIndex,destIndex,seq;
	float score,wait1Score,wait2Score,service1Score,service2Score,serviceBoard1Score,serviceBoard2Score;
	float temp;
	float currentTime;
	int car;


	wait1Score=0;wait2Score=0;service1Score=0;service2Score=0;
	serviceBoard1Score=0;serviceBoard2Score=0;
	score=0;
	for (car=0;car<MAX_CARS_IN_HOISTWAY;car++)
	{
		if (carID[car]<0) continue; // shs050810 for 1-D consideration
		currentTime=MAKE_FLOAT_TIME(carState[car].ctCurrent);
		seq=plan.sequences[car].sequence_start;
		for (stop=0;stop<nStop[car];stop++)
		{	
			// Addition of waiting time
			originIndex=plan.sequences[car].sequence[seq].first_origin_call;
			while(originIndex>=0) // check not valid
			{
				plan.de_calls[car].calls[originIndex].origin_position_time=timing[car][stop].arrivalTime;
				if (timing[car][stop].arrivalTime<plan.de_calls[car].calls[originIndex].reg_time)
				{ // after origin arrival, new call is entered
                    temp=0;
				}
				else
				{	
					if (currentTime>plan.de_calls[car].calls[originIndex].origin_position_time)
					{	// current time is after arrival time then exclude past arrival
						temp=0;
					}
					else
					{
						// call entered and arrival at the origin ( waiting time via actual mm position)
						temp=(plan.de_calls[car].calls[originIndex].origin_position_time-plan.de_calls[car].calls[originIndex].reg_time);
					}
				}
				wait1Score+=temp;
				wait2Score+=(temp*temp);
				originIndex=plan.de_calls[car].calls[originIndex].next_same_boarding;
			}
			destIndex=plan.sequences[car].sequence[seq].first_dest_call;
			while(destIndex>=0)
			{
				plan.de_calls[car].calls[destIndex].dest_position_time=timing[car][stop].arrivalTime;
				temp=(plan.de_calls[car].calls[destIndex].dest_position_time-plan.de_calls[car].calls[destIndex].reg_time);
				if (plan.de_calls[car].calls[destIndex].status==PASSENGER_WAITING  // Waiting or
					&& plan.de_calls[car].calls[destIndex].origin_position_time>=currentTime)
				{   // arrive at origin after current time --> WAITING
					// service time for waiting passenger based on Actual position viewpoint
					service1Score+=temp;
					service2Score+=(temp*temp);
				}
				else if (plan.de_calls[car].calls[destIndex].dest_position_time>currentTime)
					//if (plan.de_calls[car].calls[destIndex].status==PASSENGER_BOARDED)
				{	// arrive at destination after current time --> BOARDED
					//    service time for boarded passenger based on actual position viewpoint
					serviceBoard1Score+=temp;
					serviceBoard2Score+=(temp*temp);
				}
				destIndex=plan.de_calls[car].calls[destIndex].next_same_deboarding;
			}
			seq=plan.sequences[car].sequence[seq].next;
		}
		// coefficient multimplicaiton needed here shs tbd
	}
	score=BoardK[0]*(WaitTimeK[0]*wait1Score+WaitTimeK[1]*wait2Score
		+ServiceTimeK[0]*service1Score+ServiceTimeK[1]*service2Score); 
	score+=(BoardK[1]*(ServiceTimeK[0]*serviceBoard1Score+ServiceTimeK[1]*serviceBoard2Score));

	return score;
}

// car is uppercar=1 or lowercar=0
float HoistwaySchedule::DoorTime(int car,int floor,int board,int deboard,int type)
{
	float tDoorTime;

	switch(type)
	{
		case STOP_TYPE_CONDITIONAL:
		case STOP_TYPE_YIELD:
		case STOP_TYPE_PARKING:
		case STOP_TYPE_PIVOT:			// CSW050808: Pivot stop should be handled the same way as Yield stop
			tDoorTime=0;
			break;
		case STOP_TYPE_DEMAND:
			tDoorTime=doorClosingTime[car]+doorOpeningTime[car]+DoorDwellTime(car,floor,board,deboard,type);
			break;
		default:
			tDoorTime=0;
			break;
	}
	return tDoorTime;
}


void HoistwaySchedule::timingPrint(FILE *output)
{
	int stop,car,floor,link,othercar;
	int linktemp;
	int board,deboard;
	char carDesc[2]={'L','U'};

	for (car=0;car<MAX_CARS_IN_HOISTWAY;car++)
	{
		if (carID[car]<0) continue;  // shs080811
		othercar=(car+1)%MAX_CARS_IN_HOISTWAY;
		if (carID[othercar]<0) othercar=car; // shs080811

		fprintf(output,"~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		fprintf(output,"Car: %c, Stop: %d",carDesc[car],nStop[car]);
		fprintf(output,"\tConditional->Decel Time,Others->ArrivalTime\t\t\tplan+car.nBoard\tplan+car.nDeboard\n");
		fprintf(output,"ID\tFloor\tPred(A or D)\tType\tArrival(Decel)Time\tDoorTime\tDepartureTime\tBoard\tDeboard\n");
		fprintf(output,"~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		for (stop=0;stop<nStop[car];stop++)
		{
			link=timing[car][stop].sLink;
			floor=plan.sequences[car].sequence[link].floor;
			board=plan.sequences[car].sequence[link].boarding;
			deboard=plan.sequences[car].sequence[link].deboarding;
			fprintf(output,"[%3d]\t%4d\t",stop,floor);

			// arrival predecessor printing
			if (plan.sequences[car].sequence[link].arrival_predecessor>=0)
			{
				if (othercar ==car) //1-D
				{
					fprintf(output,"False Predirection");
				}
				else
				{
					linktemp=plan.sequences[car].sequence[link].arrival_predecessor;
					fprintf(output,"A<-%3d\t",plan.sequences[othercar].sequence[linktemp].index);
	//				fprintf(output,"[%2d]\t",linktemp);
				}
			}
			else
			{
				fprintf(output,"      \t");
			}
			// departure predecessor printing
			if (plan.sequences[car].sequence[link].departure_predecessor>=0)
			{
				if (othercar==car) //1-D
				{
					fprintf(output,"False Predirection");
				}
				else
				{
					linktemp=plan.sequences[car].sequence[link].departure_predecessor;
					fprintf(output,"D<-%3d\t",plan.sequences[othercar].sequence[linktemp].index);
//					fprintf(output,"[%2d]\t",linktemp);
				}
			}
			else
			{
				fprintf(output,"      \t");
			}

			switch(timing[car][stop].stopType)
			{
			case STOP_TYPE_CONDITIONAL:
				fprintf(output,"Conditional\t");
				fprintf(output,"%8.3f\t%8.3f\t%8.3f\t",
					timing[car][stop].decelTime,
					timing[car][stop].nominalStopDuration+timing[car][stop].extendedStopDuration,
					timing[car][stop].departureTime);
				break;
			case STOP_TYPE_YIELD:
				fprintf(output,"Yield      \t");
				fprintf(output,"%8.3f\t%8.3f\t%8.3f\t",
					timing[car][stop].arrivalTime,
					timing[car][stop].nominalStopDuration+timing[car][stop].extendedStopDuration,
					timing[car][stop].departureTime);
				break;
			case STOP_TYPE_DEMAND:
				fprintf(output,"Demand     \t");
				fprintf(output,"%8.3f\t%8.3f\t%8.3f\t",
					timing[car][stop].arrivalTime,
					timing[car][stop].nominalStopDuration+timing[car][stop].extendedStopDuration,
					timing[car][stop].departureTime);
				break;
			case STOP_TYPE_PARKING:
				fprintf(output,"Parking    \t");
				fprintf(output,"%8.3f\t%8.3f\t%8.3f\t",
					timing[car][stop].arrivalTime,
					timing[car][stop].nominalStopDuration+timing[car][stop].extendedStopDuration,
					timing[car][stop].departureTime);
				break;
			// CSW050808: Added code to print served stop
			case STOP_TYPE_SERVED:
				fprintf(output,"Served      \t");
				fprintf(output,"%8.3f\t%8.3f\t%8.3f\t",
					timing[car][stop].arrivalTime,
					timing[car][stop].nominalStopDuration+timing[car][stop].extendedStopDuration,
					timing[car][stop].departureTime);
				break;
			// CSW050808: Added code to print served stop
			// CSW050808: Added code to print served stop
			case STOP_TYPE_PIVOT:
				fprintf(output,"Pivot      \t");
				fprintf(output,"%8.3f\t%8.3f\t%8.3f\t",
					timing[car][stop].arrivalTime,
					timing[car][stop].nominalStopDuration+timing[car][stop].extendedStopDuration,
					timing[car][stop].departureTime);
				break;
			// CSW050808: Added code to print served stop
			default:
				fprintf(output,"Unknown Stop\t");
				fprintf(output,"XXXXXXXXXXXXXX\t");
				break;
			}
			if (stop==0 && (carState[car].frontDoorState==DOORS_OPENING || carState[car].frontDoorState==DOORS_OPENED))
				fprintf(output,"\t%d+%d\t%d+%d\n",board,carState[car].nBoard,deboard,carState[car].nDeboard);
			else
				fprintf(output,"\t%d\t%d\n",board,deboard);
		}

		fprintf(output,"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	}
}

void HoistwaySchedule::print(FILE *output)
{
	int stop,car,floor,link;
	fprintf(output,"/////////////////////////////\n");
	fprintf(output,"Candidate Plan\n");
	plan.print(output);
	
	for (car=0;car<MAX_CARS_IN_HOISTWAY;car++)
	{
		if (carID[car]<0) continue;  // shs080811

		fprintf(output,"Car(L=0,U=1): %d, Stop: %d\n",car,nStop[car]);
		fprintf(output,"Floor\tArrivalTime\tDoorTime\tDepartureTime\n");
		fprintf(output,"---------------------------\n");
		for (stop=0;stop<nStop[car];stop++)
		{
			link=timing[car][stop].sLink;
			floor=plan.sequences[car].sequence[link].floor;
			fprintf(output,"%4d\t%8.3f\t%8.3f\t%8.3f\n",floor,
				timing[car][stop].arrivalTime,
				timing[car][stop].nominalStopDuration+timing[car][stop].extendedStopDuration,
				timing[car][stop].departureTime);
		}
		fprintf(output,"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	}
}

// Timing modification for separation like NSP vs NCP
void HoistwaySchedule::SeparationTiming(void)
{	// TBD shs
}
void HoistwaySchedule::T_ResetDETimes(void)
{
	int car, stop;

	for (car=0;car<MAX_CARS_IN_HOISTWAY;car++)
	{
		if (carID[car]<0) continue; // shs050810 for 1-D consideration
		stop=plan.de_calls[car].sequence_start;
		while(stop>=0)
		{
			plan.de_calls[car].calls[stop].reg_time=0;
			stop=plan.de_calls[car].calls[stop].next;
		}
	}
}
