EXTERN CHAR NPIDispatcher(Call *new_call,CarState state[],TIME_T ctCurrentTime);
EXTERN void NPIInitialize();
