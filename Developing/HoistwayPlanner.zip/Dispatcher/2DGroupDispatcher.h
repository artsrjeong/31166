EXTERN CallList AssignedCalls[MAX_CAR];
EXTERN BuildingInfo	bdInfo;
EXTERN HoistwayInfo	hwyInfo[MAX_HOISTWAY];
EXTERN CarInfo			carInfo[MAX_CAR];
EXTERN Parameter		param;
