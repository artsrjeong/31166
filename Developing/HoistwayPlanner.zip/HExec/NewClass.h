// Copyright (C) 1991 - 1999 Rational Software Corporation

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_NEWCLASS_430EDB91038A_INCLUDED
#define _INC_NEWCLASS_430EDB91038A_INCLUDED


#endif /* _INC_NEWCLASS_430EDB91038A_INCLUDED */
