// Copyright (C) 1991 - 1999 Rational Software Corporation

#include "stdafx.h"
#include "NewClass.h"



