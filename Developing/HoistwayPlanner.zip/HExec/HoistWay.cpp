// HoistWay.cpp: implementation of the CHoistWay class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\2dsim_defs.h"
#include "..\hoist_exec.h"
#include "HoistWay.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHoistWay::CHoistWay()
{

}

CHoistWay::~CHoistWay()
{

}

void CHoistWay::UpdateNext(double currentTime)
{
	
}

//DEL int CHoistWay::GetHoistWayInx(int car)
//DEL {
//DEL 
//DEL }
